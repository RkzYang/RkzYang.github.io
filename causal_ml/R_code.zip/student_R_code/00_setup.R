# Shared setup for the regression-to-causal-ML student scripts.
# Each module script sources this file, then runs one slide section.

args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
entry_file <- if (length(file_arg) > 0) {
  normalizePath(sub("^--file=", "", file_arg[1]))
} else {
  normalizePath(file.path(getwd(), "seminar_design", "regression_to_causal_ml_workflow", "student_R_code", "00_setup.R"), mustWork = FALSE)
}

code_dir <- dirname(entry_file)
seminar_dir <- normalizePath(file.path(code_dir, ".."))
student_output_dir <- file.path(code_dir, "outputs")
slide_output_dir <- file.path(seminar_dir, "outputs")
dir.create(student_output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(slide_output_dir, recursive = TRUE, showWarnings = FALSE)

required_packages <- c("ggplot2", "dplyr", "rpart", "fixest")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0) {
  stop(
    "Install required packages first: ",
    paste(sprintf("install.packages('%s')", missing_packages), collapse = "; "),
    call. = FALSE
  )
}

old_define <- Sys.getenv("CML_DEFINE_FUNCTIONS_ONLY", unset = "")
old_seminar <- Sys.getenv("CML_SEMINAR_DIR", unset = "")
Sys.setenv(CML_DEFINE_FUNCTIONS_ONLY = "1")
Sys.setenv(CML_SEMINAR_DIR = seminar_dir)
source(file.path(seminar_dir, "01_workflow_upgrade_demo.R"), chdir = TRUE)
if (nzchar(old_define)) {
  Sys.setenv(CML_DEFINE_FUNCTIONS_ONLY = old_define)
} else {
  Sys.unsetenv("CML_DEFINE_FUNCTIONS_ONLY")
}
if (nzchar(old_seminar)) {
  Sys.setenv(CML_SEMINAR_DIR = old_seminar)
} else {
  Sys.unsetenv("CML_SEMINAR_DIR")
}

write_student_csv <- function(x, filename) {
  path <- file.path(student_output_dir, filename)
  write.csv(x, path, row.names = FALSE)
  message("wrote: ", path)
  invisible(path)
}

module_done <- function(name) {
  message("\nFinished ", name)
  message("Student outputs: ", student_output_dir)
  message("Slide outputs:   ", slide_output_dir)
}

print_estimates <- function(scoreboard) {
  keep <- intersect(c("estimator", "estimate", "std_error", "p_value", "true_value", "n_used"), names(scoreboard))
  print(scoreboard[, keep, drop = FALSE])
}
