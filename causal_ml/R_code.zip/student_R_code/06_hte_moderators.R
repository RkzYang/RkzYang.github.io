# Slides: Module 4 - heterogeneous treatment effects.
# Goal: turn same-sample interaction hunting into CATE discovery plus holdout validation.

args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
this_file <- if (length(file_arg) > 0) normalizePath(sub("^--file=", "", file_arg[1])) else normalizePath(file.path(getwd(), "seminar_design", "regression_to_causal_ml_workflow", "student_R_code", "06_hte_moderators.R"), mustWork = FALSE)
source(file.path(dirname(this_file), "00_setup.R"))

hetero_df <- make_dgp(scenario = "heterogeneous", seed = 404)
hte <- fit_rlearner_tree(hetero_df)
hunt <- interaction_hunt(hetero_df)

write_student_csv(hetero_df, "04_heterogeneous_effects_simulated_data.csv")
write_student_csv(hte$group_summary, "04_hte_cate_groups.csv")
write_student_csv(hunt$all_candidates, "04_interaction_hunt_candidates.csv")
write_student_csv(hunt$validation, "04_interaction_hunt_validation.csv")

plot_hte_groups(hte$group_summary, file.path(student_output_dir, "04_hte_cate_groups.png"))
plot_interaction_hunt(hunt$validation, file.path(student_output_dir, "04_interaction_hunt.png"))

print(hte$group_summary)
print(hunt$validation)

message("\nClass prompt: Which pattern is discovery, and which pattern is validation?")
message("Production tools to connect here: grf causal forests, EconML DRLearner, CausalML uplift learners.")
module_done("06_hte_moderators.R")
