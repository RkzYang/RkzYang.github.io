# Slides: Module 3 - bad controls and estimand drift.
# Goal: show why a post-treatment predictor can answer a different causal question.

args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
this_file <- if (length(file_arg) > 0) normalizePath(sub("^--file=", "", file_arg[1])) else normalizePath(file.path(getwd(), "seminar_design", "regression_to_causal_ml_workflow", "student_R_code", "05_bad_controls_estimand.R"), mustWork = FALSE)
source(file.path(dirname(this_file), "00_setup.R"))

bad_control_df <- make_dgp(scenario = "observed", seed = 303)
score_bad_control <- make_estimator_scoreboard(bad_control_df, include_bad_control = TRUE)
bad_control_roles <- data.frame(
  variable = c("treated", continuous_features, "industry", "post_attention"),
  timing = c("treatment", rep("pre-treatment", length(continuous_features)), "pre-treatment context", "post-treatment"),
  causal_role = c("focal treatment", rep("candidate confounder / precision covariate", length(continuous_features)), "blocking / context", "mediator"),
  allowed_for_total_effect = c(TRUE, rep(TRUE, length(continuous_features)), TRUE, FALSE),
  reason = c(
    "Defines the intervention",
    rep("Measured before treatment; may help block observed selection or improve precision", length(continuous_features)),
    "Context measured before treatment",
    "Affected by treatment; controlling for it changes the total-effect estimand"
  ),
  stringsAsFactors = FALSE
)

write_student_csv(score_bad_control, "03_bad_control_scoreboard.csv")
write_student_csv(bad_control_roles, "03_variable_role_audit.csv")

plot_estimator_scoreboard(
  score_bad_control,
  file.path(student_output_dir, "03_bad_control_scoreboard.png"),
  "DGP 3: bad-control estimand warning",
  highlight_bad_control = TRUE
)

print_estimates(score_bad_control)
print(bad_control_roles)

message("\nClass prompt: Which variables are allowed for the total effect, and which change the estimand?")
module_done("05_bad_controls_estimand.R")
