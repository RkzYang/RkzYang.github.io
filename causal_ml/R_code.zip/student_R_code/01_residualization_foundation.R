# Slides: Foundation - what "control for W" does.
# Goal: show that a controlled regression coefficient is a residual-on-residual slope.

args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
this_file <- if (length(file_arg) > 0) normalizePath(sub("^--file=", "", file_arg[1])) else normalizePath(file.path(getwd(), "seminar_design", "regression_to_causal_ml_workflow", "student_R_code", "01_residualization_foundation.R"), mustWork = FALSE)
source(file.path(dirname(this_file), "00_setup.R"))

old_output <- Sys.getenv("CML_OUTPUT_DIR", unset = "")
Sys.setenv(CML_OUTPUT_DIR = student_output_dir)
source(file.path(seminar_dir, "render_control_residualization_graphs.R"), chdir = TRUE)
if (nzchar(old_output)) {
  Sys.setenv(CML_OUTPUT_DIR = old_output)
} else {
  Sys.unsetenv("CML_OUTPUT_DIR")
}

metrics <- read.csv(file.path(student_output_dir, "00_control_residualization_metrics.csv"))
print(metrics)
module_done("01_residualization_foundation.R")
