# Slides: Module 2 - overlap and support.
# Goal: diagnose whether the data contain comparable treated and control units.

args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
this_file <- if (length(file_arg) > 0) normalizePath(sub("^--file=", "", file_arg[1])) else normalizePath(file.path(getwd(), "seminar_design", "regression_to_causal_ml_workflow", "student_R_code", "04_overlap_support.R"), mustWork = FALSE)
source(file.path(dirname(this_file), "00_setup.R"))

poor_overlap_df <- make_dgp(scenario = "poor_overlap", seed = 202)
score_overlap <- dplyr::bind_rows(
  make_estimator_scoreboard(poor_overlap_df),
  estimate_aipw_tree(poor_overlap_df, trim = TRUE)
)
overlap <- make_overlap_report(poor_overlap_df)

write_student_csv(poor_overlap_df, "02_poor_overlap_simulated_data.csv")
write_student_csv(score_overlap, "02_overlap_estimator_scoreboard.csv")
write_student_csv(overlap$summary, "02_overlap_summary.csv")
write_student_csv(overlap$decile, "02_overlap_deciles.csv")

plot_estimator_scoreboard(
  score_overlap,
  file.path(student_output_dir, "02_overlap_estimator_scoreboard.png"),
  "DGP 2: support-aware estimator comparison"
)
plot_overlap(
  poor_overlap_df,
  overlap,
  file.path(student_output_dir, "02_overlap_plot.png"),
  "DGP 2: propensity overlap audit"
)

print_estimates(score_overlap)
print(overlap$summary)

message("\nDecision prompt: Should this be a full-sample ATE, an ATT, a common-support ATE, or a redesign?")
module_done("04_overlap_support.R")
