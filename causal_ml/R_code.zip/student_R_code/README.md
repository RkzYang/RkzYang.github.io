# Student R Code: Regression to Causal ML Workflow

Run from the workspace root:

```r
Rscript seminar_design/regression_to_causal_ml_workflow/student_R_code/run_all.R
```

Or run one module at a time:

```r
Rscript seminar_design/regression_to_causal_ml_workflow/student_R_code/02_observed_selection_dml_aipw.R
```

Outputs go to:

```text
seminar_design/regression_to_causal_ml_workflow/student_R_code/outputs/
```

## Slide-To-Code Map

| Teaching section | Student script | What students can change |
|---|---|---|
| Foundation: control as residualization | `01_residualization_foundation.R` | Change the true `X -> Y` effect or the strength of `W` |
| Module 1: nonlinear observed selection | `02_observed_selection_dml_aipw.R` | Change the seed, learner complexity, or feature list |
| Boundary: hidden confounding | `03_hidden_confounding_sensitivity.R` | Change latent `U` strength and compare realistic versus oracle rows |
| Module 2: overlap and support | `04_overlap_support.R` | Change selection strength and inspect propensity overlap |
| Module 3: bad controls | `05_bad_controls_estimand.R` | Add or remove `post_attention` and compare total versus direct effects |
| Module 4: heterogeneous effects | `06_hte_moderators.R` | Change the heterogeneity formula and validate CATE groups |
| Production package bridge | `07_optional_production_packages.R` | Check whether `DoubleML`, `grf`, `dagitty`, or `sensemakr` are installed |

## Required Packages

The runnable classroom scripts use packages already available in this environment:

- `ggplot2`
- `dplyr`
- `rpart`
- `fixest`

The optional production bridge checks for:

- `DoubleML`
- `grf`
- `dagitty`
- `sensemakr`