# Run every student module in order.

args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
this_file <- if (length(file_arg) > 0) normalizePath(sub("^--file=", "", file_arg[1])) else normalizePath(file.path(getwd(), "seminar_design", "regression_to_causal_ml_workflow", "student_R_code", "run_all.R"), mustWork = FALSE)
code_dir <- dirname(this_file)

scripts <- c(
  "01_residualization_foundation.R",
  "02_observed_selection_dml_aipw.R",
  "03_hidden_confounding_sensitivity.R",
  "04_overlap_support.R",
  "05_bad_controls_estimand.R",
  "06_hte_moderators.R",
  "07_optional_production_packages.R"
)

rscript <- file.path(R.home("bin"), "Rscript")
for (script in scripts) {
  path <- file.path(code_dir, script)
  message("\n==============================")
  message("Running ", script)
  message("==============================")
  status <- system2(rscript, path)
  if (!identical(status, 0L)) {
    stop("Script failed: ", script, call. = FALSE)
  }
}

message("\nAll student scripts finished.")
