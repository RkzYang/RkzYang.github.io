# Slides: Boundary module - hidden confounding, sensitivity, and refutation.
# Goal: show that flexible observed adjustment cannot recover a missing common cause.

args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
this_file <- if (length(file_arg) > 0) normalizePath(sub("^--file=", "", file_arg[1])) else normalizePath(file.path(getwd(), "seminar_design", "regression_to_causal_ml_workflow", "student_R_code", "03_hidden_confounding_sensitivity.R"), mustWork = FALSE)
source(file.path(dirname(this_file), "00_setup.R"))

hidden_df <- make_hidden_confounding_dgp(seed = 111)
score_hidden <- make_hidden_confounding_scoreboard(hidden_df)

latent_diagnostics <- data.frame(
  diagnostic = c(
    "cor(hidden U, treatment)",
    "cor(hidden U, outcome)",
    "mean hidden U among treated",
    "mean hidden U among controls"
  ),
  value = c(
    cor(hidden_df$latent_quality, hidden_df$treated),
    cor(hidden_df$latent_quality, hidden_df$y),
    mean(hidden_df$latent_quality[hidden_df$treated == 1]),
    mean(hidden_df$latent_quality[hidden_df$treated == 0])
  )
)

write_student_csv(hidden_df, "01b_hidden_confounding_simulated_data.csv")
write_student_csv(score_hidden, "01b_hidden_confounding_scoreboard.csv")
write_student_csv(latent_diagnostics, "01b_latent_u_diagnostics.csv")

plot_estimator_scoreboard(
  score_hidden,
  file.path(student_output_dir, "01b_hidden_confounding_scoreboard.png"),
  "Hidden U boundary"
)

print_estimates(score_hidden)
print(latent_diagnostics)

message("\nInterpretation prompt: Which row is realistic, and which row is an impossible oracle?")
message("Production tools to connect here: DoWhy refuters, sensemakr, Oster-style sensitivity.")
module_done("03_hidden_confounding_sensitivity.R")
