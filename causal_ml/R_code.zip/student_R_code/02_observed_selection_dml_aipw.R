# Slides: Module 1 - nonlinear observed selection.
# Goal: compare the old regression workflow with DML-style residualization and AIPW.

args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
this_file <- if (length(file_arg) > 0) normalizePath(sub("^--file=", "", file_arg[1])) else normalizePath(file.path(getwd(), "seminar_design", "regression_to_causal_ml_workflow", "student_R_code", "02_observed_selection_dml_aipw.R"), mustWork = FALSE)
source(file.path(dirname(this_file), "00_setup.R"))

observed_df <- make_dgp(scenario = "observed", seed = 101)
score_observed <- make_estimator_scoreboard(observed_df)
nuisance_metrics <- make_nuisance_metrics(observed_df)

write_student_csv(observed_df, "01_observed_selection_simulated_data.csv")
write_student_csv(score_observed, "01_estimator_scoreboard.csv")
write_student_csv(nuisance_metrics, "01_nuisance_metrics.csv")

plot_estimator_scoreboard(
  score_observed,
  file.path(student_output_dir, "01_estimator_scoreboard.png"),
  "DGP 1: estimator comparison"
)
plot_nuisance_metrics(nuisance_metrics, file.path(student_output_dir, "01_nuisance_metrics.png"))

print_estimates(score_observed)
print(nuisance_metrics)

message("\nTry this: change the seed, then compare the OLS and DML rows again.")
module_done("02_observed_selection_dml_aipw.R")
