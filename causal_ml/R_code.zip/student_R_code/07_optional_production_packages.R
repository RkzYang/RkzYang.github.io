# Optional bridge to production R packages.
# This script never fails if a package is missing. It reports what is available
# and shows where the classroom demo would connect to production tools.

args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
this_file <- if (length(file_arg) > 0) normalizePath(sub("^--file=", "", file_arg[1])) else normalizePath(file.path(getwd(), "seminar_design", "regression_to_causal_ml_workflow", "student_R_code", "07_optional_production_packages.R"), mustWork = FALSE)
source(file.path(dirname(this_file), "00_setup.R"))

packages <- c("DoubleML", "grf", "dagitty", "sensemakr")
status <- data.frame(
  package = packages,
  installed = vapply(packages, requireNamespace, logical(1), quietly = TRUE),
  classroom_job = c(
    "orthogonal ATE/ATT with cross-fitting",
    "honest causal forests and CATE diagnostics",
    "DAG-based variable-role audit",
    "omitted-variable sensitivity for regression estimates"
  ),
  install_command = sprintf("install.packages('%s')", packages),
  stringsAsFactors = FALSE
)
write_student_csv(status, "07_optional_package_status.csv")
print(status)

if (requireNamespace("dagitty", quietly = TRUE)) {
  g <- dagitty::dagitty("dag { X -> D; X -> Y; D -> M; D -> Y; M -> Y; U -> D; U -> Y }")
  message("\ndagitty adjustment sets for total effect D -> Y:")
  print(dagitty::adjustmentSets(g, exposure = "D", outcome = "Y"))
}

if (requireNamespace("grf", quietly = TRUE)) {
  df <- make_dgp(scenario = "heterogeneous", seed = 404)
  x <- model.matrix(~ firm_size + prior_perf + network_centrality + market_growth +
                      analyst_coverage + digital_intensity + debt_pressure +
                      rd_intensity + export_exposure + regulatory_pressure + industry,
                    data = df)[, -1]
  cf <- grf::causal_forest(x, df$y, df$treated, num.trees = 800, seed = 404)
  tau_hat <- as.numeric(predict(cf)$predictions)
  grf_summary <- data.frame(
    mean_cate = mean(tau_hat),
    sd_cate = sd(tau_hat),
    ate_estimate = as.numeric(grf::average_treatment_effect(cf)[["estimate"]])
  )
  write_student_csv(grf_summary, "07_grf_causal_forest_summary.csv")
  print(grf_summary)
}

message("\nMissing packages are optional for the seminar. The core scripts use installed packages only.")
module_done("07_optional_production_packages.R")
